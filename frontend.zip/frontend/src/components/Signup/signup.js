import {React, useState } from "react";
import './signup.css'

function Signup(){
  const [formValue,setFormValue] = useState({name:'',email:'',mobile:'',password:''});
  const handleInput = (e)=>{
    const {name,value} =e.target;
    setFormValue({...formValue,[name]:value});
  }
  const handleSubmit = async(e)=>{
    e.preventDefault();
    const data ={name:formValue.name, email:formValue.email, mobile:formValue.mobile, password:formValue.password};
    let res = await fetch("http://localhost:8000/signup",{
      method:"POST",
      headers:{"content-type":"application/json"},
      body:JSON.stringify(data)
    });
  }
  return (<div className="parent clearfix">
      <div className="bg-illustration">
        <h1 className="bank_title">AWSome Bank</h1>
        <div className="burger-btn">
          <span />
          <span />
          <span />
        </div>
      </div>
      <div className="login">
        <div className="container">
          <h1>
            create a new account
          </h1>
          <div className="login-form">
            <form action="" method="post"  >
              <input type="text" name="name"  value={formValue.name} onChange={handleInput} placeholder="Name" />
              <input type="text" name="email" value={formValue.email} onChange={handleInput} placeholder="E-mail Address" />
              <input type="text" name="mobile" value={formValue.mobile} onChange={handleInput} placeholder="Mobile No." />
              <input type="password" name="password" value={formValue.password} onChange={handleInput} placeholder="Password" />
              <button type="submit" onClick={handleSubmit}>SIGN-UP</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Signup;